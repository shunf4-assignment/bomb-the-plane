#include "JavaHelper.h"
#include <QAndroidJniObject>
#include <QAndroidJniEnvironment>
#include <QTimer>

//extern template jint QAndroidJniObject::callStaticMethod<jint>(jclass clazz, const char *methodName, const char *sig, ...);

JavaHelper::JavaHelper(QObject *parent) : QObject(parent)
{
    ledTimer = nullptr;
    ledOn = false;
}

int JavaHelper::setLedState(int ledID, int ledState)
{
    jint result = 0;
    result = QAndroidJniObject::callStaticMethod<jint>("com/friendlyarm/AndroidSDK/HardwareControler", "setLedState", "(II)I", jint(ledID), jint(ledState));

    QAndroidJniEnvironment env;
    if (env->ExceptionCheck()) {
        env->ExceptionClear();
    }

    return result;
}

int JavaHelper::PWMPlay(int frequency)
{
    jint result = 0;
    result = QAndroidJniObject::callStaticMethod<jint>("com/friendlyarm/AndroidSDK/HardwareControler", "PWMPlay", "(I)I", jint(frequency));

    QAndroidJniEnvironment env;
    if (env->ExceptionCheck()) {
        env->ExceptionClear();
    }

    return result;
}

int JavaHelper::PWMStop()
{
    jint result = 0;
    result = QAndroidJniObject::callStaticMethod<jint>("com/friendlyarm/AndroidSDK/HardwareControler", "PWMStop", "()I");

    QAndroidJniEnvironment env;
    if (env->ExceptionCheck()) {
        env->ExceptionClear();
    }

    return result;
}

void JavaHelper::playPWMfor(int frequency, int msec)
{
    PWMPlay(frequency);

    QTimer::singleShot(msec, this, SLOT(onPWMTimeout()));
}

void JavaHelper::flashLedfor(int msecInterval)
{
    if (ledTimer == nullptr) {
        ledTimer = new QTimer(this);
        connect(ledTimer, SIGNAL(timeout()), this, SLOT(onLedTimeout()));
    }

    ledTimer->setSingleShot(false);
    ledOn = true;
    for (int i = 0; i < 4; i++) {
        setLedState(i, 1);
    }
    ledTimer->start(msecInterval);
}

void JavaHelper::stopFlashLed()
{
    if (ledTimer) {
        ledTimer->stop();
    }
    ledOn = false;
    for (int i = 0; i < 4; i++) {
        setLedState(i, 0);
    }
}

void JavaHelper::onPWMTimeout()
{
    PWMStop();
}

void JavaHelper::onLedTimeout()
{
    if (ledOn == false) {
        ledOn = true;
        for (int i = 0; i < 4; i++) {
            setLedState(i, 1);
        }
    } else {
        ledOn = false;
        for (int i = 0; i < 4; i++) {
            setLedState(i, 0);
        }
    }
}

