1. Usernames/passwords for test are:
fengshund/1652270
fengshun/1652270

For other accounts, please check btp.sql.

2. Swipe from the rightest edge of the application window to open "gaming log" drawer.
Gaming logs will be stored and displayed there.

3. The address and port of the server is fixed to 10.60.102.252:20270.